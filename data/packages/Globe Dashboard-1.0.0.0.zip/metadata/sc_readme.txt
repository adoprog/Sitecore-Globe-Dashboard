This project is based on "The WebGL Globe" by Google Data Arts Team - http://www.chromeexperiments.com/globe

This package installs only files.

"/globe" and subfolders
"/GlobeService.svc"'
"/bin/Sitecore.SharedSource.GlobeDashboard.dll"

After the installation, add the following lines to your web.config file:

  <system.serviceModel>
    <behaviors>
      <endpointBehaviors>
        <behavior name="Sitecore.SharedSource.GlobeDashboard.GlobeServiceAspNetAjaxBehavior">
          <enableWebScript />
        </behavior>
      </endpointBehaviors>
    </behaviors>
    <serviceHostingEnvironment aspNetCompatibilityEnabled="true" />
    <services>
      <service name="Sitecore.SharedSource.GlobeDashboard.GlobeService">
        <endpoint address="" behaviorConfiguration="Sitecore.SharedSource.GlobeDashboard.GlobeServiceAspNetAjaxBehavior" binding="webHttpBinding" contract="Sitecore.SharedSource.GlobeDashboard.GlobeService" />
      </service>
    </services>
  </system.serviceModel>